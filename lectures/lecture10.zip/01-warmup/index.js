const toggleFall = () => {
    /*
        Your task: target the body element and change it's class to "fall"
    */
}

const toggleWinter = () => {
    /*
        Your task: target the body element and change it's class to "winter"
    */
}

const toggleSpring = () => {
    /*
        Your task: target the body element and change it's class to "spring"
    */
}